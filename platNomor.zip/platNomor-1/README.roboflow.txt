
platNomor - v1 2022-05-30 6:20pm
==============================

This dataset was exported via roboflow.ai on May 30, 2022 at 11:20 AM GMT

It includes 36 images.
PlatNomor are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


