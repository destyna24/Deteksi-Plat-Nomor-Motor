
platNomor - v4 2022-06-22 2:19pm
==============================

This dataset was exported via roboflow.ai on June 22, 2022 at 7:23 AM GMT

It includes 542 images.
PlatNomor are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


